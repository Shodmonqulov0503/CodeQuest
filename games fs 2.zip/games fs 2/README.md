# CodeQuest

CodeQuest is a multilingual Full Stack learning arena.

The current curriculum covers 22 practical modules: HTML, CSS, JavaScript, React, TypeScript, Node.js, REST API, Databases, Git & GitHub, Web Security, Testing, DevOps, Tailwind CSS, Vue.js, Next.js, Python, Java, C#/.NET, GraphQL, Docker, Cloud/AWS, and Algorithms.

## Files

- `index.html` contains the learning flow, localized curriculum data, theory, quiz, and practice UI.
- `questions.js` contains the answer-shuffling utility used by every quiz question.
- `code-labs.js` contains high-level project examples for React, TypeScript, Next.js, Node.js, GraphQL, Docker, and CI/CD.
- `styles.css` contains the visual layer, responsive polish, focus states, and motion.

## Learning flow

1. Choose Uzbek, Russian, or English.
2. Read the topic theory.
3. Answer 50 questions.
4. Practice by writing code and running the live preview.

## High-level code labs

Open a topic and choose `Code lab` to inspect realistic project files. The React lab includes components, hooks, and `package.json`; the other labs include typed services, Next.js App Router files, Node API routes, GraphQL schema/resolvers, Docker Compose, and GitHub Actions CI.

The HTML module currently has a 200-question unique bank. Each quiz shuffles answer choices so the correct answer is not predictably placed at A. The other modules use localized starter banks and share the same theory, 50-question, and practice flow.

For the most reliable Chrome experience, run `start-chrome.bat`. It automatically picks the first free port starting from 5500 and opens that local URL, so it still works even when another service is already using port 5500. You can also open `index.html` directly; no build step is required.
