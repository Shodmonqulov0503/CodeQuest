(() => {
  const labs = {
    react: {
      title: 'React production starter',
      level: 'High-level frontend',
      description: 'Component, state, effect va reusable UI arxitekturasi bir kichik dashboardda.',
      files: {
        'src/App.jsx': `import { useEffect, useState } from 'react';
import { TaskList } from './components/TaskList';

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/tasks')
      .then(response => response.json())
      .then(data => setTasks(data))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p>Loading...</p>;
  return <TaskList tasks={tasks} onChange={setTasks} />;
}`,
        'src/components/TaskList.jsx': `export function TaskList({ tasks, onChange }) {
  function toggleTask(id) {
    onChange(tasks.map(task =>
      task.id === id ? { ...task, done: !task.done } : task
    ));
  }

  return (
    <section aria-label="Tasks">
      {tasks.map(task => (
        <button key={task.id} onClick={() => toggleTask(task.id)}>
          {task.done ? 'Done' : 'Open'}: {task.title}
        </button>
      ))}
    </section>
  );
}`,
        'src/hooks/useTasks.js': `import { useEffect, useState } from 'react';

export function useTasks() {
  const [data, setData] = useState({ items: [], status: 'loading' });

  useEffect(() => {
    fetch('/api/tasks')
      .then(response => response.json())
      .then(items => setData({ items, status: 'ready' }))
      .catch(() => setData({ items: [], status: 'error' }));
  }, []);

  return data;
}`,
        'package.json': `{
  "scripts": { "dev": "vite", "build": "vite build" },
  "dependencies": { "react": "latest", "react-dom": "latest" }
}`
      }
    },
    typescript: {
      title: 'Type-safe service layer',
      level: 'Architecture',
      description: 'Domain type, generic API response va typed service bilan katta appni tartibli tutish.',
      files: {
        'src/domain/task.ts': `export type Task = {
  id: string;
  title: string;
  done: boolean;
};

export type ApiResult<T> =
  | { ok: true; data: T }
  | { ok: false; error: string };`,
        'src/services/taskService.ts': `import type { ApiResult, Task } from '../domain/task';

export async function getTasks(): Promise<ApiResult<Task[]>> {
  const response = await fetch('/api/tasks');
  if (!response.ok) return { ok: false, error: 'Request failed' };
  return { ok: true, data: await response.json() as Task[] };
}`,
        'tsconfig.json': `{
  "compilerOptions": {
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "module": "ESNext",
    "target": "ES2022"
  }
}`
      }
    },
    next: {
      title: 'Next.js App Router',
      level: 'Full-stack React',
      description: 'Server component, route handler, loading state va metadata bilan production sahifa.',
      files: {
        'app/dashboard/page.tsx': `import { TaskCard } from '@/components/TaskCard';
import { getTasks } from '@/lib/tasks';

export const metadata = { title: 'Dashboard' };

export default async function DashboardPage() {
  const tasks = await getTasks();
  return (
    <main>
      <h1>Team dashboard</h1>
      {tasks.map(task => <TaskCard key={task.id} task={task} />)}
    </main>
  );
}`,
        'app/api/tasks/route.ts': `import { NextResponse } from 'next/server';

export async function GET() {
  const tasks = await database.task.findMany({
    orderBy: { createdAt: 'desc' }
  });
  return NextResponse.json(tasks);
}`,
        'app/loading.tsx': `export default function Loading() {
  return <p aria-live="polite">Loading dashboard...</p>;
}`
      }
    },
    node: {
      title: 'Node.js API service',
      level: 'Backend',
      description: 'Validation, async handler, clean error response va graceful server structure.',
      files: {
        'src/server.ts': `import express from 'express';
import { taskRouter } from './routes/tasks.js';

const app = express();
app.use(express.json());
app.use('/api/tasks', taskRouter);
app.use((error, request, response, next) => {
  console.error(error);
  response.status(500).json({ error: 'Internal server error' });
});
app.listen(process.env.PORT ?? 3000);`,
        'src/routes/tasks.ts': `import { Router } from 'express';
import { taskService } from '../services/taskService.js';

export const taskRouter = Router();

taskRouter.get('/', async (request, response, next) => {
  try {
    response.json(await taskService.list());
  } catch (error) {
    next(error);
  }
});`,
        'package.json': `{
  "type": "module",
  "scripts": { "dev": "tsx watch src/server.ts" },
  "dependencies": { "express": "latest", "zod": "latest" }
}`
      }
    },
    graphql: {
      title: 'GraphQL schema design',
      level: 'Data contract',
      description: 'Schema-first API, resolver va client query bilan kerakli fieldlarni aniq boshqarish.',
      files: {
        'schema.graphql': `type Task {
  id: ID!
  title: String!
  done: Boolean!
}

type Query {
  tasks: [Task!]!
}

type Mutation {
  toggleTask(id: ID!): Task!
}`,
        'src/resolvers.ts': `export const resolvers = {
  Query: {
    tasks: (_, __, { db }) => db.task.findMany()
  },
  Mutation: {
    toggleTask: async (_, { id }, { db }) => {
      const task = await db.task.findUniqueOrThrow({ where: { id } });
      return db.task.update({
        where: { id },
        data: { done: !task.done }
      });
    }
  }
};`,
        'src/queries.ts': `export const TASKS_QUERY = ` + "`" + `
  query Tasks {
    tasks { id title done }
  }
` + "`" + `;`
      }
    },
    docker: {
      title: 'Production container setup',
      level: 'Delivery',
      description: 'Multi-stage build, minimal runtime image va health check bilan deployga tayyor servis.',
      files: {
        'Dockerfile': `FROM node:22-alpine AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM node:22-alpine AS runtime
WORKDIR /app
ENV NODE_ENV=production
COPY --from=build /app/package*.json ./
RUN npm ci --omit=dev
COPY --from=build /app/dist ./dist
EXPOSE 3000
CMD ["node", "dist/server.js"]`,
        'compose.yaml': `services:
  api:
    build: .
    ports: ["3000:3000"]
    environment:
      DATABASE_URL: postgresql://app:app@db:5432/app
    depends_on: [db]
  db:
    image: postgres:16-alpine
    environment:
      POSTGRES_USER: app
      POSTGRES_PASSWORD: app
      POSTGRES_DB: app`,
        '.dockerignore': `node_modules
.git
.env
      coverage`
      }
    },
    devops: {
      title: 'CI/CD quality gate',
      level: 'Automation',
      description: 'Pull request ochilganda install, test, build va deploy bosqichlarini avtomatlashtirish.',
      files: {
        '.github/workflows/ci.yml': `name: CI
on: [pull_request, push]
jobs:
  verify:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 22, cache: npm }
      - run: npm ci
      - run: npm run lint
      - run: npm test -- --runInBand
      - run: npm run build`,
        'package.json': `{
  "scripts": {
    "lint": "eslint .",
    "test": "vitest",
    "build": "tsc --noEmit && vite build"
  }
}`
      }
    }
  };

  window.CodeQuestLabs = {
    get(topicId) {
      return labs[topicId] || labs.react;
    }
  };
})();
