@echo off
cd /d "%~dp0"

set "PORT=5500"

:find_port
powershell -NoProfile -Command "$port = %PORT%; $listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $port); try { $listener.Start(); Write-Output 'FREE' } catch { Write-Output 'BUSY' } finally { $listener.Stop() }" > "%TEMP%\codequest_port_check.txt"
set /p PORT_STATUS=<"%TEMP%\codequest_port_check.txt"

if /I "%PORT_STATUS%"=="BUSY" (
	set /a PORT+=1
	if %PORT% GEQ 5600 (
		echo No free local port found between 5500 and 5599.
		exit /b 1
	)
	goto find_port
)

echo Starting CodeQuest on http://localhost:%PORT%/index.html
start "CodeQuest server" /b cmd /c "npx --yes http-server -p %PORT% -c-1"
timeout /t 2 /nobreak >nul
start "" "http://localhost:%PORT%/index.html"
